import { Directive, ElementRef, Input} from '@angular/core';

@Directive ({
  // tslint:disable-next-line:directive-selector
  selector: '[dropzone]'
})

// tslint:disable-next-line:directive-class-suffix
export class DropzoneUpload {
  $el: any;

  constructor(el: ElementRef) {
    this.$el = jQuery(el.nativeElement);
  }

  // tslint:disable-next-line:use-life-cycle-interface use-lifecycle-interface
  ngOnInit(): void {
    const dropzone = new Dropzone(this.$el[0], {
      addRemoveLinks: true
    });
    Dropzone.autoDiscover = false;
   // Dropzone.options.myAwesomeDropzone = false;
  }

}
