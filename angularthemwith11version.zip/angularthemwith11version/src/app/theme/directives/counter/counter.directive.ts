import { Directive, ElementRef, Input } from '@angular/core';

@Directive ({
  // tslint:disable-next-line:directive-selector
  selector: '[counter]'
})

// tslint:disable-next-line:directive-class-suffix
export class Counter {
  element: any;
  @Input() count: number | undefined;
  @Input() interval: number | undefined;
  @Input() increment: number | undefined;

  // tslint:disable-next-line:variable-name
  constructor(_elementRef: ElementRef) {
    this.element = jQuery(_elementRef.nativeElement);
  }

  // tslint:disable-next-line:use-life-cycle-interface use-lifecycle-interface
  ngAfterViewInit(): void {
    // tslint:disable-next-line:prefer-const one-variable-per-declaration
      let elem = this.element,
          count = this.count,
        // tslint:disable-next-line:prefer-const
          increment = this.increment,
        // tslint:disable-next-line:prefer-const
          interval = this.interval;

    // tslint:disable-next-line:typedef
      function counter() {
          // @ts-ignore
        count = count + increment;
        // @ts-ignore
        setTimeout(() => counter(), interval * 1000);
        elem.html(count.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','));
      }
      counter();
  }
}
