import { Directive, ElementRef, Input } from '@angular/core';
import 'skycons/skycons';

@Directive ({
  // tslint:disable-next-line:directive-selector
  selector: '[skycon]'
})

// tslint:disable-next-line:directive-class-suffix
export class Skycon {
  $el: any;
  @Input() color: string | undefined;
  @Input() weather: string | undefined;

  constructor(el: ElementRef) {
    this.$el = jQuery(el.nativeElement);
  }

  // tslint:disable-next-line:use-lifecycle-interface
  ngOnInit(): void {
    const icons = new Skycons({color: this.color});
    icons.set(this.$el[0], this.weather);
    icons.play();
  }
}
