import { Directive, ElementRef } from '@angular/core';
import 'metrojs/release/MetroJs.Full/MetroJs';

@Directive ({
  // tslint:disable-next-line:directive-selector
  selector: '[live-tile]'
})

// tslint:disable-next-line:directive-class-suffix
export class LiveTile {
  $el: any;

  constructor(el: ElementRef) {
    this.$el = jQuery(el.nativeElement);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnInit(): void {
    this.$el
      .css('height', this.$el.data('height'))
      .liveTile();
  }
}
