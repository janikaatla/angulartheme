import { Directive, ElementRef } from '@angular/core';

@Directive ({
  // tslint:disable-next-line:directive-selector
  selector: '[progress-animate]'
})

// tslint:disable-next-line:directive-class-suffix
export class ProgressAnimate {
    public element: any;

  // tslint:disable-next-line:variable-name
    constructor(private _elementRef: ElementRef) {
        this.element = jQuery(_elementRef.nativeElement);
    }

  // tslint:disable-next-line:use-lifecycle-interface
    ngOnInit(): void {
      // tslint:disable-next-line:prefer-const one-variable-per-declaration
        let elem = this.element,
            progress = 0,
          // tslint:disable-next-line:prefer-const
            timeout = 0,
          // tslint:disable-next-line:prefer-const
            increment = 1,
          // tslint:disable-next-line:prefer-const
            maxprogress = elem.attr('aria-valuenow');
      // tslint:disable-next-line:typedef
        function animate() {
            setTimeout(() => {
                progress += increment;
                if (progress < maxprogress) {
                    elem.css('width', progress + '%');
                    animate();
                }
            }, timeout);
        }
        animate();
    }

    // ngOnInit(): void {
    //     let width = this.element.attr('aria-valuenow'),
    //     $bar = this.element;
    //     $bar.css('opacity', 0);
    //     setTimeout(() => {
    //         $bar.css({
    //             transition: 'none',
    //             width: 0,
    //             opacity: 1
    //         });
    //         setTimeout(() => {
    //             $bar.css('transition', '').css('width', width+'%');
    //         });
    //     });
    // }


}
