import {Directive, Input, Output, ElementRef, EventEmitter} from '@angular/core';
import 'jquery-slimscroll';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[slim-scroll]'
})
// tslint:disable-next-line:directive-class-suffix
export class SlimScroll {

  // tslint:disable-next-line:ban-types
  @Input() public slimScrollOptions: Object | undefined;

  // tslint:disable-next-line:variable-name
  private _changes: any;
  // tslint:disable-next-line:variable-name
  constructor(private _elementRef: ElementRef) {
  }

  // tslint:disable-next-line:typedef use-lifecycle-interface
  ngOnChanges(changes: any) {
    this._changes = changes;
    this._scroll();
  }

  // tslint:disable-next-line:typedef
  private _scroll() {
    this._destroy();
    this._init();
  }

  // tslint:disable-next-line:typedef
  private _init() {
    jQuery(this._elementRef.nativeElement).slimScroll(this.slimScrollOptions);
  }

  // tslint:disable-next-line:typedef
  private _destroy() {
    jQuery(this._elementRef.nativeElement).slimScroll({ destroy: true });
  }
}
