import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'SearchPipe' })
export class SearchPipe implements PipeTransform {
  // @ts-ignore
  transform(value: any[], args?: string | RegExp): Array<any> {
    // @ts-ignore
    const searchText = new RegExp(args, 'ig');
    if (value) {
      // @ts-ignore
      return value.filter(person => {
        if (person.name) {
          return person.name.search(searchText) !== -1;
        }
      });
    }
  }
}
