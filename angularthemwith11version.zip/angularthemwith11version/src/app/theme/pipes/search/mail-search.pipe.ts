import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'MailSearch'
})

export class MailSearchPipe implements PipeTransform {
  // @ts-ignore
  transform(value: any[], args?: string | RegExp): Array<any> {
    // @ts-ignore
    const searchText = new RegExp(args, 'ig');
    if (value) {
      // @ts-ignore
      return value.filter(mail => {
        if (mail.sender || mail.subject){
          if (mail.sender.search(searchText) !== -1 || mail.subject.search(searchText) !== -1){
            return true;
          }
        }
      });
    }
  }
}
