import { Component, OnInit, ViewEncapsulation, ElementRef, HostListener } from '@angular/core';
import { Router, ActivatedRoute , NavigationEnd } from '@angular/router';
import { MenuService } from './menu.service';
import { AppState } from '../../../app.state';

@Component({
  // tslint:disable-next-line:component-selector
    selector: 'az-menu',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.scss'],
    providers: [ MenuService ]
})

export class MenuComponent implements OnInit {
    public menuItems: Array<any>;
    public menuHeight: number | undefined;
    public isMenuCollapsed = false;
    public isMenuShouldCollapsed = false;
    public showHoverElem: boolean | undefined;
    public hoverElemHeight: number | undefined;
    public hoverElemTop: number | undefined;

  // tslint:disable-next-line:variable-name
    constructor(private _elementRef: ElementRef,
                // tslint:disable-next-line:variable-name
                private _router: Router,
                // tslint:disable-next-line:variable-name
                private _activatedRoute: ActivatedRoute,
                // tslint:disable-next-line:variable-name
                private _menuService: MenuService,
                // tslint:disable-next-line:variable-name
                private _state: AppState) {

        this.menuItems = _menuService.getMenuItems();
        this._state.subscribe('menu.isCollapsed', (isCollapsed: boolean) => {
            this.isMenuCollapsed = isCollapsed;
        });

        this._router.events.subscribe(event => {
            if (event instanceof NavigationEnd) {
                const width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
                if (width <= 768){
                    this._state.notifyDataChanged('menu.isCollapsed', true);
                }
                window.scrollTo(0, 0);
            }
        });

    }

    public ngOnInit(): void {
        if (this._shouldMenuCollapse()) {
            this.menuCollapse();
        }
        this.updateSidebarHeight();
    }

    @HostListener('window:resize')
    public onWindowResize(): void {
        const isMenuShouldCollapsed = this._shouldMenuCollapse();

        if (this.isMenuShouldCollapsed !== isMenuShouldCollapsed) {
            this.menuCollapseStateChange(isMenuShouldCollapsed);
        }
        this.isMenuShouldCollapsed = isMenuShouldCollapsed;
        this.updateSidebarHeight();
    }

    private _shouldMenuCollapse(): boolean {
        return window.innerWidth <= 768;
    }

    public menuCollapse(): void {
        this.menuCollapseStateChange(true);
    }

    public menuCollapseStateChange(isCollapsed: boolean): void {
        this.isMenuCollapsed = isCollapsed;
        this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);
    }

    public menuExpand(): void {
        this.menuCollapseStateChange(false);
    }

    public updateSidebarHeight(): void {
       this.menuHeight =  this._elementRef.nativeElement.children[0].clientHeight - 84;
    }

  // tslint:disable-next-line:max-line-length
    public hoverItem($event: any, item: any): void {
        this.showHoverElem = true;
        this.hoverElemHeight = $event.currentTarget.clientHeight;
        this.hoverElemTop = $event.currentTarget.getBoundingClientRect().top - 60;
    }

    public collapseMenu($event: { currentTarget: any; }, item: any): boolean{
        const link = jQuery($event.currentTarget);
        if (this.isMenuCollapsed) {
            this.isMenuCollapsed = false;
            this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);
            if (link.parent().hasClass('sidebar-item-expanded')) {
                return false;
            }
            else{
                link.parent().parent().find('li').removeClass('sidebar-item-expanded');
                link.parent().parent().find('li .sidebar-sublist').slideUp(250);
                link.parent().addClass('sidebar-item-expanded');
              // tslint:disable-next-line:only-arrow-functions typedef
                setTimeout(function() {
                    link.next().css('display', 'block');
                }, 250);
                link.next().slideDown(250);
            }
        }
        else{
            if (link.parent().hasClass('sidebar-item-expanded')) {
                link.parent().removeClass('sidebar-item-expanded');
                link.next().slideUp(250);
            } else {
                link.parent().parent().find('li').removeClass('sidebar-item-expanded');
                link.parent().parent().find('li .sidebar-sublist').slideUp(250);
                link.parent().addClass('sidebar-item-expanded');
                link.next().slideDown(250);
            }
        }
        return false;
    }


}
