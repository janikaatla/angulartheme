import {Component, ViewEncapsulation} from '@angular/core';

import {MessagesService} from './messages.service';

@Component({
    selector: 'az-messages',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./messages.component.scss'],
    templateUrl: './messages.component.html',
    providers: [MessagesService]
})

export class MessagesComponent {
  // tslint:disable-next-line:ban-types
    public messages: any[];
  // tslint:disable-next-line:ban-types
    public notifications: any[];
  // tslint:disable-next-line:ban-types
    public tasks: any[];

  // tslint:disable-next-line:variable-name
    constructor(private _messagesService: MessagesService){
        this.messages = _messagesService.getMessages();
        this.notifications = _messagesService.getNotifications();
        this.tasks = _messagesService.getTasks();
    }

}
