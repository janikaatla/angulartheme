import { SidebarItem } from './sidebar-item.model';

export const sidebarItems = [
    new SidebarItem (1, 'Dashboard', 'pages/dashboard', '', 'fa-home', '', false, 0),
    new SidebarItem (2, 'Charts', '', '', 'fa-bar-chart', '', true, 0),
    new SidebarItem (3, 'Ng2-Charts', 'pages/charts/ng2charts', '', 'fa-caret-right', '', false, 2),
    new SidebarItem (4, 'UI Features', '', '', 'fa-laptop', '', true, 0), new SidebarItem (5, 'Buttons', 'pages/ui/buttons', '', 'fa-caret-right', '', false, 4),
    new SidebarItem (6, 'Cards', 'pages/ui/cards', '', 'fa-caret-right', '', false, 4), new SidebarItem (7, 'Components', 'pages/ui/components', '', 'fa-caret-right', '', false, 4), new SidebarItem (8, 'Icons', 'pages/ui/icons', '', 'fa-caret-right', '', false, 4), new SidebarItem (9, 'Grid', 'pages/ui/grid', '', 'fa-caret-right', '', false, 4), new SidebarItem (10, 'List Group', 'pages/ui/list-group', '', 'fa-caret-right', '', false, 4), new SidebarItem (11, 'Media Objects', 'pages/ui/media-objects', '', 'fa-caret-right', '', false, 4),  new SidebarItem (12, 'Tabs & Accordions', 'pages/ui/tabs-accordions', '', 'fa-caret-right', '', false, 4), new SidebarItem (13, 'Typography', 'pages/ui/typography', '', 'fa-caret-right', '', false, 4), new SidebarItem (14, 'Tools', '', '', 'fa-wrench', '', true, 0), new SidebarItem (15, 'Drag & Drop', 'pages/tools/drag-drop', '', 'fa-caret-right', '', false, 14), new SidebarItem (16, 'Resizable', 'pages/tools/resizable', '', 'fa-caret-right', '', false, 14), new SidebarItem (17, 'Toaster', 'pages/tools/toaster', '', 'fa-caret-right', '', false, 14),   new SidebarItem (18, 'Mail', 'pages/mail/mail-list/inbox', '', 'fa-envelope-o', '', false, 0), new SidebarItem (19, 'Calendar', 'pages/calendar', '', 'fa-calendar', '', false, 0), new SidebarItem (20, 'Form Elements', '', '', 'fa-pencil-square-o', '', true, 0), new SidebarItem (21, 'Form Inputs', 'pages/form-elements/inputs', '', 'fa-caret-right', '', false, 20),
    new SidebarItem (22, 'Form Layouts', 'pages/form-elements/layouts', '', 'fa-caret-right', '', false, 20),
    new SidebarItem (23, 'Form Validations', 'pages/form-elements/validations', '', 'fa-caret-right', '', false, 20),
    new SidebarItem (24, 'Form Wizard', 'pages/form-elements/wizard', '', 'fa-caret-right', '', false, 20),
    new SidebarItem (25, 'Tables', '', '', 'fa-table', '', true, 0), new SidebarItem (26, 'Basic Tables', 'pages/tables/basic-tables', '', 'fa-caret-right', '', false, 25),
    new SidebarItem (27, 'Dynamic Tables', 'pages/tables/dynamic-tables', '', 'fa-caret-right', '', false, 25),
    new SidebarItem (28, 'Editors', '', '', 'fa-pencil', '', true, 0), new SidebarItem (29, 'Froala Editor', 'pages/editors/froala-editor', '', 'fa-caret-right', '', false, 28),
    new SidebarItem (30, 'Ckeditor', 'pages/editors/ckeditor', '', 'fa-caret-right', '', false, 28),
    new SidebarItem (31, 'Maps', '', '', 'fa-globe', '', true, 0), new SidebarItem (32, 'Vector Maps', 'pages/maps/vectormaps', '', 'fa-caret-right', '', false, 31),
    new SidebarItem (33, 'Google Maps', 'pages/maps/googlemaps', '', 'fa-caret-right', '', false, 31),
    new SidebarItem (34, 'Leaflet Maps', 'pages/maps/leafletmaps', '', 'fa-caret-right', '', false, 31),
    new SidebarItem (35, 'Pages', '', '', 'fa-file-o', '', true, 0), new SidebarItem (36, 'Login', '/login', '', 'fa-caret-right', '', false, 35),
    new SidebarItem (37, 'Register', '/register', '', 'fa-caret-right', '', false, 35),
    new SidebarItem (38, 'Blank Page', 'pages/blank', '', 'fa-caret-right', '', false, 35),
  // tslint:disable-next-line:max-line-length
    new SidebarItem (39, 'Error Page', '/pagenotfound', '', 'fa-caret-right', '', false, 35),   new SidebarItem (140, 'Menu Level 1', '', '', 'fa-folder-open-o', '', true, 0),
    new SidebarItem (141, 'Menu Level 2', '', '', 'fa-folder-open-o', '', true, 140),
    new SidebarItem (142, 'MenuLevel 3', '', '', 'fa-folder-open-o', '', true, 141),
    new SidebarItem (143, 'MenuLevel 4', '', '', 'fa-folder-open-o', '', true, 142),
    new SidebarItem (144, 'MenuLevel 5', '', '', 'fa-folder-o', '', false, 143), new SidebarItem (200, 'External Link', '', 'http://themeseason.com', 'fa-external-link', '_blank', false, 0)
];
