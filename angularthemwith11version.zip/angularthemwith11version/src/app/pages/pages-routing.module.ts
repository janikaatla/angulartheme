import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { PagesComponent } from './pages.component';
import {BlankComponent} from './blank/blank.component';

const routes: Routes = [{ path: '', component: PagesComponent,
  children: [
    { path: '', redirectTo: 'blank', pathMatch: 'full' },
    { path: 'blank', component: BlankComponent, data: { breadcrumb: 'Blank page' } }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }
