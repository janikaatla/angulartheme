import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PagesRoutingModule } from './pages-routing.module';
import { PagesComponent } from './pages.component';
import { BlankComponent } from './blank/blank.component';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

import {PipesModule} from '../theme/pipes/pipes.module';
import {DirectivesModule} from '../theme/directives/directives.module';

import {ToastrModule} from 'ngx-toastr';

import {BackTopComponent} from '../theme/components/back-top/back-top.component';
import {BreadcrumbComponent} from '../theme/components/breadcrumb/breadcrumb.component';
import {MessagesComponent} from '../theme/components/messages/messages.component';
import {SidebarComponent} from '../theme/components/sidebar/sidebar.component';
import {MenuComponent} from '../theme/components/menu/menu.component';
import {NavbarComponent} from '../theme/components/navbar/navbar.component';
import {AppState} from '../app.state';


@NgModule({
  declarations: [
    PagesComponent,
    BlankComponent,
    BackTopComponent,
    BreadcrumbComponent,
    MessagesComponent,
    MenuComponent,
    NavbarComponent,
    SidebarComponent,
  ],
  imports: [
    CommonModule,
    PagesRoutingModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    ToastrModule.forRoot(),
  ],
  providers: [
    AppState,
    Location,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class PagesModule { }
