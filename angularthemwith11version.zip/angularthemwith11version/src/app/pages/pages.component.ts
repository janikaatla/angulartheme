import { Component, OnInit } from '@angular/core';
import {AppState} from '../app.state';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})
export class PagesComponent implements OnInit {

  public isMenuCollapsed = false;
  // tslint:disable-next-line:typedef
  ngOnInit() {
  }

  public hideMenu(): void {
    console.log('hide menu');
  }

}
