import {Injectable} from '@angular/core';
// @ts-ignore
import {Subject} from 'rxjs/Subject';

@Injectable()
export class AppState {

  // tslint:disable-next-line:variable-name ban-types
  private _data = new Subject<Object>();
  // tslint:disable-next-line:variable-name
  private _dataStream$ = this._data.asObservable();

  // tslint:disable-next-line:ban-types variable-name
  private _subscriptions: Map<string, Array<Function>> = new Map<string, Array<Function>>();

  constructor() {
    this._dataStream$.subscribe((data: any) => this._onEvent(data));
  }

  // tslint:disable-next-line:typedef
  notifyDataChanged(event: string, value: boolean) {

    // @ts-ignore
    let current = this._data[event];
    // tslint:disable-next-line:triple-equals
    if (current != value) {
      // @ts-ignore
      this._data[event] = value;
      current = value;

      this._data.next({
        event,
        data: current
      });
    }
  }

  // tslint:disable-next-line:typedef ban-types
  subscribe(event: string, callback: Function) {
    const subscribers = this._subscriptions.get(event) || [];
    subscribers.push(callback);

    this._subscriptions.set(event, subscribers);
  }

  // tslint:disable-next-line:typedef
  _onEvent(data: any) {
    const subscribers = this._subscriptions.get(data.event) || [];

    subscribers.forEach((callback) => {
      callback.call(null, data.data);
    });
  }
}
