/* SystemJS module definition */
declare var jQuery: any;
declare var Dropzone: any;
declare var d3: any;
declare var Datamap: any;
declare var L: any;
declare var Skycons: any;
/*declare var module: NodeModule;
interface NodeModule {
  id: string;
}*/
