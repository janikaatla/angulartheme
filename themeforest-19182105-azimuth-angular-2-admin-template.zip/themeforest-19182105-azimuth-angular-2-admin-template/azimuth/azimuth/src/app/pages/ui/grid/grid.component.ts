import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-grid',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent  { }
