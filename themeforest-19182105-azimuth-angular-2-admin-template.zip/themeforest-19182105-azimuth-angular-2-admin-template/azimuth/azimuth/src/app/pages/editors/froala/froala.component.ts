import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-froala',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './froala.component.html'
})
export class FroalaComponent { }
