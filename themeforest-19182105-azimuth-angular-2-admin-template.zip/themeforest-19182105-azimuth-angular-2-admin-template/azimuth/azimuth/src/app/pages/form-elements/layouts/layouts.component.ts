import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-layouts',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './layouts.component.html'
})
export class LayoutsComponent { }
