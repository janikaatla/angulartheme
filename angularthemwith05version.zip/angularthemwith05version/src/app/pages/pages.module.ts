import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};
/*import { ToastrModule } from 'ngx-toastr';
import { BlankComponent } from './blank/blank.component';
import {DirectivesModule} from "../themes/directives/directives.module";
import {PipesModule} from "../themes/pipes/pipes.module";*/
import {routing} from "./pages.routing";
import {PagesComponent} from "./pages.component";
import {BlankComponent} from "./blank/blank.component";
/*import {MenuComponent} from "../themes/components/menu/menu.component";
import {SidebarComponent} from "../themes/components/sidebar/sidebar.component";
import {NavbarComponent} from "../themes/components/navbar/navbar.component";
import {MessagesComponent} from "../themes/components/messages/messages.component";
import {BreadcrumbComponent} from "../themes/components/breadcrumb/breadcrumb.component";
import {BackTopComponent} from "../themes/components/back-top/back-top.component";*/



@NgModule({
  declarations: [PagesComponent,
    BlankComponent,
    /*BlankComponent,
    MenuComponent,
    SidebarComponent,
    NavbarComponent,
    MessagesComponent,
    BreadcrumbComponent,
    BackTopComponent*/
  ],
  imports: [
    CommonModule,
    PerfectScrollbarModule,
    /*ToastrModule.forRoot(),
    DirectivesModule,
    PipesModule,*/
    routing
  ],
  providers:[
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class PagesModule { }
