import {Type} from '@angular/core';

export class Tab {
  public id: number | undefined;
  public uniqueId: number | undefined;
  public title: string;
  public tabData: any;
  public active: boolean | undefined;
  public component: Type<any>;
  public batchInfoId: number | undefined;
  public batchId: string | undefined;

  constructor(component: Type<any>, title: string, tabData: any) {
    this.tabData = tabData;
    this.component = component;
    this.title = title;
  }
}
