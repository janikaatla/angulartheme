import {Directive, ElementRef} from '@angular/core';

@Directive({
  selector: '[appLiveTile]'
})
export class LiveTileDirective {
  $el: any;

  constructor(el: ElementRef) {
    this.$el = jQuery(el.nativeElement);
  }

  ngOnInit(): void {
    this.$el
      .css('height', this.$el.data('height'))
      .liveTile();
  }

}
