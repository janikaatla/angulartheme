import {Directive, ElementRef, Input} from '@angular/core';

@Directive({
  selector: '[slimScroll]'
})
export class SlimScrollDirective {
  @Input() public slimScrollOptions: Object | undefined;
  private _changes: any;

  constructor(private _elementRef:ElementRef) {
  }

  ngOnChanges(changes: any) {
    this._changes = changes;
    this._scroll();
  }

  private _scroll() {
    this._destroy();
    this._init();
  }

  private _init() {
    // jQuery(this._elementRef.nativeElement).slimScroll(this.slimScrollOptions);
  }

  private _destroy() {
    // jQuery(this._elementRef.nativeElement).slimScroll({ destroy: true });
  }

}
