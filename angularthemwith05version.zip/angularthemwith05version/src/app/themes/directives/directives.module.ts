import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {CounterDirective} from "./counter.directive";
import {DropzoneDirective} from "./dropzone.directive";
import {LiveTileDirective} from "./live-tile.directive";
import {ProgressAnimateDirective} from "./progress-animate.directive";
import {SkyconDirective} from "./skycon.directive";
import {SlimScrollDirective} from "./slim-scroll.directive";
import {WidgetDirective} from "./widget.directive";



@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    CounterDirective,
    DropzoneDirective,
    LiveTileDirective,
    ProgressAnimateDirective,
    SkyconDirective,
    SlimScrollDirective,
    WidgetDirective
  ],
  exports: [
    CounterDirective,
    DropzoneDirective,
    LiveTileDirective,
    ProgressAnimateDirective,
    SkyconDirective,
    SlimScrollDirective,
    WidgetDirective
  ]

})
export class DirectivesModule { }
