import {Directive, ElementRef} from '@angular/core';

@Directive({
  selector: '[appDropzone]'
})
export class DropzoneDirective {
  $el: any;
  private Dropzone: any;

  constructor(el: ElementRef) {
    this.$el = jQuery(el.nativeElement);
  }

  ngOnInit(): void {
    // @ts-ignore
    let dropzone = new DropzoneDirective(this.$el[0], {
      addRemoveLinks: true
    });
    this.Dropzone.autoDiscover = false;
    // Dropzone.options.myAwesomeDropzone = false;
  }

}
