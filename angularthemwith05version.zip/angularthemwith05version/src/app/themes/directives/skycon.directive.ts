import {Directive, ElementRef, Input} from '@angular/core';

@Directive({
  selector: '[skycon]'
})
export class SkyconDirective {
  $el: any;
  @Input() color: string='';
  @Input() weather: string='';

  constructor(el: any) {
    this.$el = jQuery(el.nativeElement);
  }

  ngOnInit(): void {
    let icons = new SkyconDirective({'color': this.color});
    /*icons.set(this.$el[0], this.weather);
    icons.play();*/
  }

}
