import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {MessagesService} from "./messages.service";

@Component({
  selector: 'app-messages',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss'],
  providers: [MessagesService]
})
export class MessagesComponent {
  public messages:Array<Object>;
  public notifications:Array<Object>;
  public tasks:Array<Object>;

  constructor (private _messagesService:MessagesService){
    this.messages = _messagesService.getMessages();
    this.notifications = _messagesService.getNotifications();
    this.tasks = _messagesService.getTasks();
  }

}
