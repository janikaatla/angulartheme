import {Component, OnInit, ViewEncapsulation} from '@angular/core';
import {SidebarService} from "../sidebar/sidebar.service";
import {AppState} from "../../../app.state";

@Component({
  selector: 'app-navbar',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
  providers: [ SidebarService ]
})
export class NavbarComponent implements OnInit {

  public isMenuCollapsed:boolean = false;

  constructor(private _state:AppState, private _sidebarService:SidebarService) {
    this._state.subscribe('menu.isCollapsed', (isCollapsed: boolean) => {
      this.isMenuCollapsed = isCollapsed;
    });
  }

  public closeSubMenus(){
    /* when using <az-sidebar> instead of <az-menu> uncomment this line */
    // this._sidebarService.closeAllSubMenus();
  }

  public toggleMenu() {
    this.isMenuCollapsed = !this.isMenuCollapsed;
    this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);
  }

  ngOnInit(): void {
  }

}
