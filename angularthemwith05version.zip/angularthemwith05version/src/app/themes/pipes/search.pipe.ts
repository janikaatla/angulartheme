import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  // @ts-ignore
  transform(value:any, args?: string | RegExp | undefined): Array<any> {
    // @ts-ignore
    let searchText = new RegExp(args, 'ig');
    if (value) {
      // @ts-ignore
      return value.filter((person: { name: string; }) => {
        if (person.name) {
          return person.name.search(searchText) !== -1;
        }
      });
    }
  }

}
