import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppPicturePipe } from './app-picture.pipe';
import { ProfilePicturePipe } from './profile-picture.pipe';
import { SearchPipe } from './search.pipe';
import { MailSearchPipe } from './mail-search.pipe';



@NgModule({
    declarations: [AppPicturePipe, ProfilePicturePipe, SearchPipe, MailSearchPipe],
    exports: [
        ProfilePicturePipe
    ],
    imports: [
        CommonModule
    ]
})
export class PipesModule { }
