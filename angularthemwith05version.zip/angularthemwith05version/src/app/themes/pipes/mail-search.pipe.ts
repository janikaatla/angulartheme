import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'mailSearch'
})
export class MailSearchPipe implements PipeTransform {

  // @ts-ignore
  transform(value, args?): Array<any> {
    let searchText = new RegExp(args, 'ig');
    if (value) {
      // @ts-ignore
      return value.filter((mail: { sender: string; subject: string; }) => {
        if(mail.sender || mail.subject){
          if(mail.sender.search(searchText) !== -1 || mail.subject.search(searchText) !== -1){
            return true;
          }
        }
      });
    }
  }

}
