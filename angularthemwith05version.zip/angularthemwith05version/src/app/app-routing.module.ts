
import {Routes, RouterModule, PreloadAllModules} from '@angular/router';
import {ModuleWithProviders, NgModule} from '@angular/core';
/*import {LayoutComponent} from "./appConfigs/layout/layout.component";
import {TabComponent} from "./appConfigs/tab/tab.component";
import { LoginComponent } from './appConfigs/login/login.component'; */

const routes: Routes = [
  { path: '', redirectTo: 'pages', pathMatch: 'full' },
  { path: 'pages', loadChildren: 'app/pages/pages.module#PagesModule' }
  /*{path: '', component: LoginComponent},
  {
    path: 'layout',
    component: LayoutComponent,
    data: {
      title: 'Home',
    },
    children: [
      {
        path: '',
        redirectTo: 'tab',
        pathMatch: 'full'
      },
      {
        path: 'tab',
        component: TabComponent
      }]
  }*/
];

/*export const routing: ModuleWithProviders<any> = RouterModule.forRoot(routes, {
  preloadingStrategy: PreloadAllModules,
  // useHash: true
});*/

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: PreloadAllModules,
    useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
