import { Component, OnInit } from '@angular/core';
import {AppService} from "../../appServices/app.service";

@Component({
  selector: 'app-itemmenu',
  templateUrl: './itemmenu.component.html',
  styleUrls: ['./itemmenu.component.scss']
})
export class ItemmenuComponent implements OnInit {

  constructor(private appService:AppService) { }

  ngOnInit(): void {
    this.appService.showLoader();
    setTimeout(() => {
      console.log('hide');
      this.appService.hideLoader();
    }, 4000);

  }

}
